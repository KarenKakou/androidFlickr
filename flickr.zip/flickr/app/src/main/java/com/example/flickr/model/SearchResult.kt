package com.example.flickr.model

class SearchResult(val photos: Photos, val stat: String) {
}