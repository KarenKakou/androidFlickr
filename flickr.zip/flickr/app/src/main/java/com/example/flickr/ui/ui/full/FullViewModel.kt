package com.example.flickr.ui.ui.full

import androidx.lifecycle.ViewModel

class FullViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
